AIRKU - Project Android
=========================
Source: airku-2-2-5.html

This project wraps the AIRKU HTML application with Capacitor.
To produce an APK, run:
  npm install
  npx cap add android
  npx cap sync android
  npx cap open android

A real APK cannot be produced in this environment because the Android SDK/Gradle
toolchain is not available here. The HTML app itself is included unchanged as
www/index.html.
